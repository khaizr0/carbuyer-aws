const BASE_URL = window.location.origin;
const mapConfig = {
    url: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2098.047098103885!2d106.70327503669084!3d10.772062044514472!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752f3acf87eaeb%3A0xc969a1975f3be32a!2sBitexco%20Financial%20Tower!5e0!3m2!1svi!2s!4v1760106692113!5m2!1svi!2s'
};
